<div class="form-group">
                            <label class="control-label col-md-3">Jenis Kelamin</label>
                            <div class="col-md-9">
                                <input type="text" name="jk_dokter" class="form-control" placeholder="Masukkann Jenis Kelamin">
                                <span class="help-block"></span>
                            </div>
                        </div>


    <style type="text/css">
        .modalEdit{
            width: 100%;
        }


<script src="assets/plugins/notifyjs/js/notify.js"></script>
        <script src="assets/plugins/notifications/notify-metro.js"></script>





                        <div class="form-group modalEdit">
                            <label class="control-label col-md-3">Jenis Kelamin</label>
                            <div class="col-md-9">
                                <input type="text" name="jk_dokter" class="form-control" style="width:100%" value="'.$item->jk_dokter.'">
                                <span class="help-block"></span>
                            </div>
                        </div>